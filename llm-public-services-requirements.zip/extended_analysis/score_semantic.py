"""Reproduce exploratory ChatGPT-assisted semantic ratings and aggregate statistics.
Usage: python score_semantic.py <results dir> <analysis dir>.
No independent human review was performed. Codes are explicit judgments, not regex predictions.
"""
import pathlib, csv, re, sys, statistics, collections, json, math, hashlib

def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter=';'))
def write(p,rows):
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter=';');w.writeheader();w.writerows(rows)
def mean(v):return statistics.mean(v)
def percent(n,d):return n/d if d else None

def main(src,out):
 runs=read(src/'runs.csv');rules=read(src/'reference_rules.csv');manifest=json.loads((src/'manifest.json').read_text(encoding='utf-8-sig'));cfg=manifest['config']
 assert len(runs)==90 and len({r['id'] for r in runs})==90
 assert hashlib.sha256((src/'reference_rules.csv').read_bytes()).hexdigest()==cfg['reference_sha256']
 for s,h in cfg['corpus_sha256'].items():assert hashlib.sha256((src/'corpora'/(s+'.txt')).read_bytes()).hexdigest()==h
 codes={}
 for line in (out/'semantic_codes.tsv').read_text().splitlines():
  if not line or line.startswith('#'):continue
  id,raw=line.split('\t');assert id not in codes
  c={}
  for val in raw.split():
   m=re.fullmatch(r'(\d+)([FPC])([\d,-]+)',val);assert m,val
   k=int(m[1]);assert k not in c;c[k]=(dict(F='full',P='partial',C='conflict')[m[2]],m[3])
  codes[id]=c
 assert set(codes)=={r['id'] for r in runs}
 rows=[];per=[]
 for r in runs:
  t=(src/(r['id']+'.txt')).read_text(encoding='utf-8-sig'); lines=t.splitlines(); local=[]
  for rule in [z for z in rules if z['service']==r['service']]:
   label,ref=codes[r['id']].get(int(rule['rule_id'][1:]),('absent',''));indices=[]
   for seg in ref.split(',') if ref else []:
    n=seg.split('-');indices.extend(range(int(n[0]),int(n[-1])+1))
   assert all(1<=i<=len(lines) for i in indices)
   excerpt=' || '.join(f'{i}: {lines[i-1].strip()}' for i in indices if lines[i-1].strip())
   reason={'full':'Основные компоненты правила переданы; явного противоречия не выявлено.','partial':'Есть относящийся к правилу фрагмент, но не все существенные условия или действия воспроизведены; возможна дополнительная неподтверждённая детализация.','conflict':'Фрагмент содержит несовместимое с эталоном условие, срок, действие или субъект; при наличии корректного фрагмента приоритет отдан противоречию.','absent':''}[label]
   item=dict(id=r['id'],service=r['service'],model=r['model'],mode=r['mode'],repeat=r['repeat'],status=r['status'],rule_id=rule['rule_id'],source=rule['source'],critical=rule['critical'],reference=rule['rule'],label=label,evidence_lines=ref,evidence=excerpt[:3500],reason=reason)
   rows.append(item);local.append(item)
  crit=[i for i in local if i['critical']=='1'];n=len(local);nc=len(crit);c=collections.Counter(z['label'] for z in local);cc=collections.Counter(z['label'] for z in crit)
  assert n and nc
  per.append(dict(r,empty=int(not t.strip()),rules=n,critical_rules=nc,full=c['full'],partial=c['partial'],absent=c['absent'],conflict=c['conflict'],critical_full=cc['full'],critical_partial=cc['partial'],critical_absent=cc['absent'],critical_conflict=cc['conflict'],coverage=c['full']/n,critical_coverage=cc['full']/nc,conflict_share=c['conflict']/n,critical_conflict_share=cc['conflict']/nc))
 assert len(rows)==930 and sum(z['critical']=='1' for z in rows)==630
 assert all(z['evidence'] for z in rows if z['label']!='absent')
 write(out/'semantic_ratings.csv',rows);write(out/'semantic_per_run.csv',per)
 def summary(g,cols):
  out=[]
  for k in sorted({tuple(v[c] for c in cols) for v in g}):
   q=[v for v in g if tuple(v[c] for c in cols)==k];out.append(dict(zip(cols,k),n=len(q),completed=sum(v['status']=='ok' for v in q),empty=sum(v['empty'] for v in q),**{c:sum(v[c] for v in q) for c in ['rules','critical_rules','full','partial','absent','conflict','critical_full','critical_partial','critical_absent','critical_conflict']},**{c:mean(v[c] for v in q) for c in ['coverage','critical_coverage','conflict_share','critical_conflict_share']}))
  return out
 for name,cols in [('model_mode',['model','mode']),('service_mode',['service','mode']),('cell',['model','service','mode']),('mode',['mode']),('model',['model']),('service',['service'])]:write(out/f'semantic_{name}.csv',summary(per,cols))
 pairs=collections.defaultdict(dict)
 for p in per:pairs[(p['model'],p['service'],p['repeat'])][p['mode']]=p
 pairrows=[]
 for k,d in sorted(pairs.items()):
  assert set(d)=={'A','B'};pairrows.append(dict(model=k[0],service=k[1],repeat=k[2],A=d['A']['id'],B=d['B']['id'],**{'delta_'+c:d['B'][c]-d['A'][c] for c in ['coverage','critical_coverage','conflict_share','critical_conflict_share']}))
 assert len(pairrows)==45;write(out/'paired_differences.csv',pairrows)
 tests=[]
 for model in ['all']+sorted(set(p['model'] for p in per)):
  q=[p for p in pairrows if model=='all' or p['model']==model]
  for col in ['delta_coverage','delta_critical_coverage','delta_conflict_share']:
   v=[p[col] for p in q];pos=sum(x>1e-9 for x in v);neg=sum(x< -1e-9 for x in v);ties=len(v)-pos-neg;nn=pos+neg;pval=min(1,2*sum(math.comb(nn,j) for j in range(min(pos,neg)+1))/(2**nn)) if nn else 1
   tests.append(dict(model=model,metric=col,n=len(v),mean_delta=mean(v),median_delta=statistics.median(v),positive=pos,negative=neg,ties=ties,exploratory_sign_test_p=pval))
 write(out/'paired_summary.csv',tests)
 byrule=[]
 for r in rules:
  local=[z for z in rows if z['rule_id']==r['rule_id']];cnt=collections.Counter(z['label'] for z in local);byrule.append(dict(r,**{x:cnt[x] for x in ['full','partial','absent','conflict']}))
 write(out/'rule_summary.csv',byrule)
 # Sensitivity of result to keyword-based screen; explicitly not agreement of independent experts.
 screen=read(out/'lexical_screen.csv');lex={(v['id'],v['rule_id']):v for v in screen};assert len(lex)==930
 cmp=[]
 for z in rows:
  s=lex[(z['id'],z['rule_id'])];cmp.append(dict(id=z['id'],rule_id=z['rule_id'],semantic_full=int(z['label']=='full'),narrow=int(s['narrow']),wide=int(s['wide'])))
 write(out/'method_comparison.csv',cmp)
 comparison={}
 for mode in ('narrow','wide'):
  c=collections.Counter((z['semantic_full'],z[mode]) for z in cmp);a=sum(n for (u,v),n in c.items() if u==v);comparison[mode]=dict(n=len(cmp),agreement=a/len(cmp),true_positive=c[1,1],false_positive=c[0,1],false_negative=c[1,0],true_negative=c[0,0])
 # Reproducible review subset: repeat=1 per cell, same subset for human raters, no reference to model in packet.
 sub=[p for p in per if p['repeat']=='1']; assert len(sub)==18
 write(out/'review_subset.csv',[{k:v for k,v in x.items() if k in ['id','service','model','mode','repeat','status']} for x in sub])
 totals=collections.Counter(z['label'] for z in rows);crit=collections.Counter(z['label'] for z in rows if z['critical']=='1');info={'runs':len(runs),'completed':sum(p['status']=='ok' for p in per),'empty':sum(p['empty'] for p in per),'ratings':len(rows),'critical_ratings':sum(crit.values()),'labels':dict(totals),'critical_labels':dict(crit),'method_comparison':comparison,'subset_runs':len(sub),'subset_ratings':sum(p['rules'] for p in sub),'subset_critical':sum(p['critical_rules'] for p in sub),'independent_expert_kappa':None,'status':'provisional ChatGPT-assisted, non-blind; no independent expert review'}
 (out/'summary.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(info,ensure_ascii=False,indent=2))
 print('\nmodel mode:');print(*summary(per,['model','mode']),sep='\n');print('\nmode:');print(*summary(per,['mode']),sep='\n')
 print('\npaired:');print(*tests,sep='\n')
if __name__=='__main__':main(pathlib.Path(sys.argv[1]),pathlib.Path(sys.argv[2]))
