"""Exploratory lexical screening, NOT a substitute for semantic expert ratings.
Usage: python screen.py <results dir> <output dir>. Standard library only.
For every reference rule: narrow=all features on a line or a pair of adjacent
nonempty lines; wide=all features somewhere in answer. Neither tests entailment.
"""
import csv, re, sys, pathlib, collections, json, statistics
# Components deliberately require specifics; patterns are interpretable, not trained.
P={
'R01':[r'сфр|социальн\w* фонд|территориальн\w* орган',r'решени\w*',r'выдач|выдать|выдаче',r'отказ',r'(?:\b5\b|пят[ьи])\s*рабоч',r'(?:при[её]м|поступлени|приняти)\w*\s+заявлен'],
'R02':[r'приостан|приостанов',r'не\s*поступ|неполуч|не\s*получ|отсутств',r'запрош|запрос',r'срок|част[ьи]\s*4'],
'R03':[r'приостан|не\s*поступ|неполуч|отсутств\w*\s+сведен',r'решени',r'(?:\b15\b|пятнадцат)\w*\s*рабоч',r'(?:при[её]м|поступлени|приняти)\w*\s+заявлен'],
'R04':[r'сфр|фонд',r'провер',r'достоверн',r'документ',r'вправе|право|мож|возможност'],
'R05':[r'сфр|фонд',r'дополнительн\w*\s+(?:сведен|данн)|(?:сведен|данн)\w*\s+дополнительн',r'запрос|запраш',r'орган',r'смэв|межведомствен',r'необходимост|вправе|мож|возможност'],
'R06':[r'орган',r'рассмотр\w*',r'запрос',r'(?:\b1\b|один|одного)\s*рабоч',r'поступлен|получен'],
'R07':[r'сфр|фонд|территориальн\w* орган',r'уведом|сообщ|направ|оповещ',r'заявител|получател',r'представител',r'положительн|удовлетворен|выдач',r'отрицательн|отказ',r'(?:\b1\b|один|одного)\s*рабоч',r'приняти\w*\s+решен|вынесени\w*\s+решен'],
'R08':[r'уведом|сообщ|оповещ',r'мфц',r'епгу|госуслуг',r'ин\w*\s+способ|друг\w*\s+(?:способ|канал)',r'5[.,]2',r'178'],
'R09':[r'выписк',r'сертификат',r'ецп|централизованн\w* цифров',r'сфр',r'мфц',r'получ|предостав'],
'R10':[r'отказ|отрицательн',r'уведом',r'причин|основан'],
'R11':[r'оспар|обжал|пересмотр',r'вышестоящ',r'сфр|фонд',r'суд',r'установлен\w*\s+поряд'],
'I01':[r'документ',r'представ|подач|подать',r'(?:ст(?:атья|атьи|ать[еёй])?\.?\s*9\b)'],
'I02':[r'копи',r'нотари',r'исключен|кроме|не\s*треб|без\s*нотари|непосредствен|личн',r'оригинал',r'предъяв|представ',r'регистрирующ\w*\s+орган'],
'I03':[r'оригинал',r'возврат|возвращ',r'расписк',r'(?:ст(?:атья|атьи|ать[еёй])?\.?\s*9\b)',r'(?:пункт|п\.)\s*3\b'],
'I04':[r'регистр',r'(?:\b3\b|тр[иеёх]+)\s*рабоч',r'(?:представлен|подач|при[её]м)\w*\s+документ',r'регистрирующ\w*\s+орган',r'(?:пункт|п\.)\s*1\b'],
'I05':[r'регистр',r'запрещ|запрет|блокир|не\s*(?:допуск|позвол|мож)',r'действующ|действует|уже\s+зарегистрирован|ранее\s+зарегистрирован',r'\bип\b|предпринимател'],
'I06':[r'запрещ|запрет|блокир|не\s*(?:допуск|позвол|мож)',r'суд',r'прекращ',r'принудительн',r'\bгод\w*|\b1\s*год',r'решени'],
'I07':[r'запрещ|запрет|блокир|не\s*(?:допуск|позвол|мож)',r'суд',r'приговор',r'предпринимательск',r'срок|период|действу|истеч|окончан'],
'I08':[r'запрещ|запрет|блокир|не\s*(?:допуск|позвол|мож)',r'егрип',r'исключен',r'(?:\b3\b|тр[иеёх]+)\s*(?:год|лет)',r'решени\w*\s+регистрирующ\w*\s+орган'],
'I09':[r'запрещ|запрет|блокир|не\s*(?:допуск|позвол|мож)|ограничен',r'216',r'127',r'(?:пункт|п\.)\s*2\b'],
'B01':[r'регистр|брак|заявлен',r'соблюд|соответств|услови|требован',r'12\b',r'13\b',r'156\b',r'семейн|\bск\b',r'(?:пункт|п\.)\s*1\b'],
'B02':[r'регистр',r'после\s+истечени\w*\s+месяц|по\s+истечени\w*\s+месяц|не\s+ранее\s+(?:одного\s+)?месяц|через\s+(?:один\s+)?месяц',r'(?:12|двенадцат)\w*\s*месяц',r'совместн\w*\s+заявлен',r'загс'],
'B03':[r'выбор|выбира|выбрать',r'дат',r'врем',r'совместн\w*\s+заявлен|совместн\w*\s+подач',r'интервал|свободн|доступн',r'загс',r'федеральн\w*\s+информационн'],
'B04':[r'брак|регистр',r'раньше|досроч|до\s+истечени',r'месяц',r'уважительн',r'совместн\w*\s+заявлен',r'загс'],
'B05':[r'брак|регистр',r'тот\s+же\s+день|день\s+(?:подач|заявлен)',r'особ\w*\s+обстоятельств',r'беремен',r'рождени\w*\s+реб[её]н',r'угроз\w*\s+жизн'],
'B06':[r'руководител\w*\s+загс',r'измен|поменя',r'дат',r'врем',r'совместн\w*\s+заявлен'],
'B07':[r'присутств|явк',r'обоих|оба',r'брак|регистр'],
'B08':[r'тяж[её]л\w*\s+болезн|тяж[её]л\w*\s+заболеван',r'уважительн',r'дома|на\s+дому|домашн',r'медицинск',r'ин\w*\s+организац',r'присутств\w*\s+обоих|оба\s+присутств',r'не\s+мог|невозможн'],
'B09':[r'под\s+страж|заключ[её]н',r'отбыва|лишени\w*\s+свобод',r'помещен|место',r'начальник\w*\s+учрежден',r'соглас',r'руководител\w*\s+загс'],
'B10':[r'препятств',r'блокир|запрещ|невозмож|недопуст|не\s*(?:допуск|позвол|мож)|отказ',r'14\b',r'156\b',r'(?:пункт|п\.)\s*2\b',r'семейн|\bск\b'],
'B11':[r'руководител\w*\s+загс',r'доказательств',r'препятств',r'отказ',r'вправе|мож|право|возможност']}

def read(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter=';'))
def write(p,rows):
 with p.open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter=';');w.writeheader();w.writerows(rows)
def main(src,out):
 out.mkdir(parents=True,exist_ok=True);runs=read(src/'runs.csv');rules=read(src/'reference_rules.csv');results=[];per=[]
 for r in runs:
  text=(src/(r['id']+'.txt')).read_text(encoding='utf-8-sig');lines=[(i,s.strip()) for i,s in enumerate(text.splitlines(),1) if s.strip()];windows=[(str(i),s) for i,s in lines]+[(f'{i}-{j}',s+' '+t) for (i,s),(j,t) in zip(lines,lines[1:])];local=[]
  for rule in [x for x in rules if x['service']==r['service']]:
   patterns=[re.compile(s,re.I) for s in P[rule['rule_id']]]; wide=[bool(p.search(text)) for p in patterns];fullw=[(loc,s) for loc,s in windows if all(p.search(s) for p in patterns)]; best=max(windows,key=lambda v:sum(bool(p.search(v[1])) for p in patterns),default=('', ''));item=dict(id=r['id'],service=r['service'],model=r['model'],mode=r['mode'],repeat=r['repeat'],rule_id=rule['rule_id'],critical=rule['critical'],components=len(patterns),hits=sum(wide),wide=int(all(wide)),narrow=int(bool(fullw)),evidence_lines=fullw[0][0] if fullw else best[0] if any(wide) else '',evidence=(fullw[0][1] if fullw else best[1] if any(wide) else '')[:1000]);local.append(item);results.append(item)
  crit=[z for z in local if z['critical']=='1'];per.append(dict(r,empty=int(not text.strip()),narrow=statistics.mean(z['narrow'] for z in local),wide=statistics.mean(z['wide'] for z in local),narrow_crit=statistics.mean(z['narrow'] for z in crit),wide_crit=statistics.mean(z['wide'] for z in crit)))
 write(out/'lexical_screen.csv',results);write(out/'per_run_screen.csv',per)
 gs=[]
 for k in sorted({(r['model'],r['mode']) for r in per}):
  g=[r for r in per if (r['model'],r['mode'])==k];gs.append(dict(model=k[0],mode=k[1],n=len(g),completed=sum(r['status']=='ok' for r in g),empty=sum(r['empty'] for r in g),**{col:statistics.mean(r[col] for r in g) for col in ['narrow','wide','narrow_crit','wide_crit']}))
 write(out/'screen_summary.csv',gs);print(len(results),sum(z['critical']=='1' for z in results));print(json.dumps(gs,ensure_ascii=False,indent=2))
if __name__=='__main__': main(pathlib.Path(sys.argv[1]),pathlib.Path(sys.argv[2]))
