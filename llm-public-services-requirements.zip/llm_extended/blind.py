"""Prepare two identical blind scoring packages, keep key with study coordinator."""
import argparse,csv,json,pathlib,random,shutil
from run import read

def main():
 p=argparse.ArgumentParser();p.add_argument('results',type=pathlib.Path);p.add_argument('--out',type=pathlib.Path,required=True);a=p.parse_args();r=a.results;o=a.out
 jobs=read(r/'manifest.json')['config']['jobs']; items=[]
 for j in jobs:
  file=r/(j['id']+'.json')
  if not file.exists() or read(file)['status']=='error':raise SystemExit('Завершите все запланированные попытки и исправьте технические ошибки перед созданием слепых пакетов.')
  items.append((j,read(file)))
 random.Random(723541).shuffle(items);o.mkdir(parents=True,exist_ok=False)
 with (r/'reference_rules.csv').open(encoding='utf-8-sig',newline='') as f:rules=list(csv.DictReader(f,delimiter=';'))
 key=[];rows=[];index=[]
 for i,(j,record) in enumerate(items,1):
  blind=f'X{i:03}';key.append(dict(blind_id=blind,**j,status=record['status']));index.append([blind,j['service']]);
  for rule in rules:
   if rule['service']==j['service']:rows.append([blind,j['service'],rule['rule_id'],rule['source'],rule['rule'],rule['critical'],'',''])
 (o/'private_key.json').write_text(json.dumps(key,ensure_ascii=False,indent=2),encoding='utf-8')
 for who in ['reviewer_1','reviewer_2']:
  dest=o/who;dest.mkdir();(dest/'answers').mkdir();shutil.copytree(r/'corpora',dest/'corpora');shutil.copy2(r/'reference_rules.csv',dest/'reference_rules.csv');shutil.copy2(pathlib.Path(__file__).with_name('REVIEW.md'),dest/'REVIEW.md')
  for (j,rec),k in zip(items,key):(dest/'answers'/f"{k['blind_id']}.txt").write_text(rec['response']['message']['content'],encoding='utf-8')
  with (dest/'ratings.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.writer(f,delimiter=';');w.writerow(['blind_id','service','rule_id','source','rule','critical','label','evidence']);w.writerows(rows)
  with (dest/'index.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.writer(f,delimiter=';');w.writerow(['blind_id','service']);w.writerows(index)
 print('Пакеты созданы. private_key.json не отправлять экспертам.')
if __name__=='__main__':main()
