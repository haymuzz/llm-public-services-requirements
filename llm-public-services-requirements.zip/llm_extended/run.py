"""Local Ollama experiment. Python 3.10+, standard library only."""
import argparse, csv, datetime, hashlib, itertools, json, pathlib, random, time, urllib.request, sys, shutil
ROOT=pathlib.Path(__file__).resolve().parent
MODELS=['deepseek-r1:1.5b','qwen2.5:1.5b','gemma3:4b']
COMMON='Используй только приведённые исходные сведения. Сформируй функциональные требования к информационной системе указанной услуги, для каждого — проверяемый критерий приёмки. Не более 15 различных требований, без повторов; не добавляй сведения извне. Не раскрывай содержание отсутствующих отсылочных норм. Ответ на русском языке.\n'
PROMPTS={'A':COMMON+'Представь требования и критерии приёмки в удобном формате.', 'B':COMMON+'Представь таблицу: нормативный пункт | субъект | условие применимости | действие | срок, единица и начало отсчёта (если применимо) | исключение | функциональное требование | критерий приёмки. Отсутствующие сведения пометь «не указано»; допущения отдели от нормативных правил.'}
OPTIONS={'temperature':0.2,'num_ctx':8192,'num_predict':4096}
def api(base,path,payload=None):
 req=urllib.request.Request(base.rstrip('/')+path,data=None if payload is None else json.dumps(payload,ensure_ascii=False).encode('utf-8'),headers={'Content-Type':'application/json'})
 with urllib.request.urlopen(req,timeout=1800) as r:return json.load(r)
def dump(path,data):
 tmp=path.with_suffix(path.suffix+'.tmp');tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(path)
def read(path):return json.loads(path.read_text(encoding='utf-8'))
def sha(raw):return hashlib.sha256(raw).hexdigest()
def journal(out,jobs):
 with (out/'runs.csv').open('w',encoding='utf-8-sig',newline='') as f:
  w=csv.writer(f,delimiter=';');w.writerow(['id','service','model','mode','repeat','status','done_reason','elapsed_seconds','eval_count','prompt_eval_count'])
  for j in jobs:
   p=out/(j['id']+'.json');r=read(p) if p.exists() else {};s=r.get('response',{});w.writerow([j[k] for k in ['id','service','model','mode','repeat']]+[r.get('status','pending'),s.get('done_reason',''),r.get('elapsed_seconds',''),s.get('eval_count',''),s.get('prompt_eval_count','')])
def main():
 a=argparse.ArgumentParser();a.add_argument('--out',type=pathlib.Path,required=True);a.add_argument('--models',nargs='+',default=MODELS);a.add_argument('--repeats',type=int,default=5);a.add_argument('--base',default='http://127.0.0.1:11434');a.add_argument('--retry-errors',action='store_true');a.add_argument('--max-new',type=int,default=0,help='0 = all pending');a.add_argument('--plan-only',action='store_true');args=a.parse_args();out=args.out.resolve()
 if args.repeats<1 or len(set(args.models))!=len(args.models) or args.max_new<0:a.error('Некорректные параметры')
 sources=read(ROOT/'sources.json'); texts={s:(ROOT/'corpora'/f'{s}.txt').read_bytes() for s in sources};rules=(ROOT/'reference_rules.csv').read_bytes();
 rawjobs=list(itertools.product(sorted(sources),args.models,['A','B'],range(1,args.repeats+1)));random.Random(20261127).shuffle(rawjobs)
 jobs=[dict(id=f'E{i:03}',service=s,model=m,mode=mode,repeat=r) for i,(s,m,mode,r) in enumerate(rawjobs,1)]
 config={'sources':sources,'corpus_sha256':{s:sha(t) for s,t in texts.items()},'reference_sha256':sha(rules),'models_requested':args.models,'prompts':PROMPTS,'options':OPTIONS,'repetitions':args.repeats,'jobs':jobs,'seed_policy':'202600 + repeat; paired A/B','order_seed':20261127}
 if args.plan_only:print(json.dumps({'planned':len(jobs),'models':args.models,'services':list(sources),'repeats':args.repeats},ensure_ascii=False));return
 try:
  available={m['name']:m for m in api(args.base,'/api/tags')['models']};version=api(args.base,'/api/version')
 except Exception as e:sys.exit(f'Ollama недоступна: {e}')
 missing=set(args.models)-available.keys()
 if missing:sys.exit('Не установлены: '+', '.join(sorted(missing)))
 config['model_digests']={m:available[m].get('digest') for m in args.models};config['ollama_version']=version
 manifest=out/'manifest.json'
 if manifest.exists():
  old=read(manifest)
  if old['config']!=config:sys.exit('Конфигурация или версия модели изменилась. Выберите новую папку; старые результаты не перезаписываются.')
 else:
  if out.exists() and any(out.iterdir()):sys.exit('Папка непуста и не является результатом этого эксперимента. Выберите другую.')
  out.mkdir(parents=True,exist_ok=True);(out/'corpora').mkdir(exist_ok=True)
  for s,t in texts.items():(out/'corpora'/f'{s}.txt').write_bytes(t)
  (out/'reference_rules.csv').write_bytes(rules);dump(manifest,{'config':config,'model_details':{m:available[m] for m in args.models},'created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
 journal(out,jobs);done=0
 for j in jobs:
  rid=j['id']; path=out/(rid+'.json')
  if path.exists():
   if read(path)['status']!='error' or not args.retry_errors:continue
   archive=out/'technical_errors';archive.mkdir(exist_ok=True);shutil.copy2(path,archive/(rid+'_'+str(time.time_ns())+'.json'))
  if args.max_new and done>=args.max_new:break
  prompt=PROMPTS[j['mode']]+'\nУслуга: '+sources[j['service']]['name']+'\nВыбранные исходные сведения:\n'+texts[j['service']].decode('utf-8-sig')
  payload={'model':j['model'],'messages':[{'role':'user','content':prompt}],'stream':False,'options':dict(OPTIONS,seed=202600+j['repeat'])}
  r=dict(j,request=payload,started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat());t=time.monotonic()
  print(rid,j['service'],j['model'],j['mode'],j['repeat'],'...',flush=True)
  try:
   response=api(args.base,'/api/chat',payload);r['response']=response;content=response['message']['content'];r['status']='ok' if content.strip() and response.get('done_reason')=='stop' else 'incomplete';(out/(rid+'.txt')).write_text(content,encoding='utf-8')
  except Exception as e:r['status']='error';r['error']=repr(e)
  r['elapsed_seconds']=time.monotonic()-t;dump(path,r);journal(out,jobs);done+=1;print(rid,r['status'],flush=True)
  if r['status']=='error':sys.exit('Техническая ошибка: '+r['error']+'\nПосле исправления запустите ту же команду с --retry-errors. Ошибка сохранена.')
 print(f'Новых попыток: {done}. Журнал: {out / "runs.csv"}')
if __name__=='__main__':main()
