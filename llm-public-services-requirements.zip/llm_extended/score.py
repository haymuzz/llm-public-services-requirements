"""Require complete independent ratings; compare labels, generate disagreement sheet and group results."""
import argparse,csv,json,pathlib,collections,statistics
LABELS=['full','partial','absent','conflict']
def readcsv(p):
 with p.open(encoding='utf-8-sig',newline='') as f:return list(csv.DictReader(f,delimiter=';'))
def write(p,header,rows):
 with p.open('w',encoding='utf-8-sig',newline='') as f:w=csv.writer(f,delimiter=';');w.writerow(header);w.writerows(rows)
def kappa(a,b):
 n=len(a);agree=sum(x==y for x,y in zip(a,b))/n;ca=collections.Counter(a);cb=collections.Counter(b);expected=sum(ca[k]*cb[k] for k in ca.keys()|cb.keys())/(n*n);return agree,None if expected==1 else (agree-expected)/(1-expected)
def main():
 p=argparse.ArgumentParser();p.add_argument('blind',type=pathlib.Path);p.add_argument('--out',type=pathlib.Path,required=True);p.add_argument('--adjudicated',type=pathlib.Path);a=p.parse_args();base=a.blind;key={j['blind_id']:j for j in json.loads((base/'private_key.json').read_text(encoding='utf-8'))};rules=readcsv(base/'reviewer_1'/'reference_rules.csv');expected={(bid,r['rule_id']):r for bid,j in key.items() for r in rules if r['service']==j['service']}
 def load(path):
  out={}
  for r in readcsv(path):
   k=(r['blind_id'],r['rule_id']);v=r['label'].strip().lower()
   if k in out or k not in expected or v not in LABELS:raise SystemExit(f'Недопустимая, повторная или незаполненная оценка: {path}: {k} {v!r}')
   if v!='absent' and not r['evidence'].strip():raise SystemExit(f'Нужно обоснование: {path} {k}')
   out[k]=v
  if set(out)!=set(expected):raise SystemExit(f'Не хватает оценок в {path}')
  return out
 x=load(base/'reviewer_1'/'ratings.csv');y=load(base/'reviewer_2'/'ratings.csv');keys=sorted(expected);agree,k=kappa([x[z] for z in keys],[y[z] for z in keys]);ab,kb=kappa([x[z]=='full' for z in keys],[y[z]=='full' for z in keys]);a.out.mkdir(parents=True,exist_ok=False)
 (a.out/'agreement.json').write_text(json.dumps({'n_rule_ratings':len(keys),'agreement_4class':agree,'kappa_4class':k,'agreement_full_binary':ab,'kappa_full_binary':kb},indent=2),encoding='utf-8')
 write(a.out/'adjudication_template.csv',['blind_id','service','rule_id','label_rater1','label_rater2','label','evidence'],[[bid,expected[(bid,rule)]['service'],rule,x[(bid,rule)],y[(bid,rule)],x[(bid,rule)] if x[(bid,rule)]==y[(bid,rule)] else '', ''] for bid,rule in keys]);
 if a.adjudicated:z=load(a.adjudicated)
 elif x==y:z=x
 else:print('Согласие рассчитано. Заполните adjudication_template.csv (включая обоснования для всех непустых правил) и запустите score.py с --adjudicated и новой выходной папкой.');return
 per=[]
 for bid,j in key.items():
  local=[(k,r) for k,r in expected.items() if k[0]==bid];v=[z[k] for k,r in local];critical=[z[k] for k,r in local if r['critical']=='1'];per.append(dict(j,coverage=v.count('full')/len(v),critical_coverage=critical.count('full')/len(critical),conflict_share=v.count('conflict')/len(v)))
 cols=['id','service','model','mode','repeat','status','coverage','critical_coverage','conflict_share'];write(a.out/'per_run.csv',cols,[[v[c] for c in cols] for v in per]);groups=collections.defaultdict(list)
 for v in per:groups[(v['service'],v['model'],v['mode'])].append(v)
 write(a.out/'summary.csv',['service','model','mode','n','completion_rate','mean_coverage','mean_critical_coverage','mean_conflict_share'],[[*g,len(v),sum(t['status']=='ok' for t in v)/len(v),*[statistics.mean(t[c] for t in v) for c in cols[-3:]]] for g,v in sorted(groups.items())]);
 pairs=collections.defaultdict(dict)
 for v in per:pairs[(v['service'],v['model'],v['repeat'])][v['mode']]=v
 write(a.out/'paired_differences.csv',['service','model','repeat','delta_coverage_B_minus_A','delta_critical_coverage_B_minus_A','delta_conflict_share_B_minus_A'],[[*g,*[v['B'][c]-v['A'][c] for c in cols[-3:]]] for g,v in sorted(pairs.items()) if set(v)=={'A','B'}]);print('Готово:',a.out)
if __name__=='__main__':main()
