"""Проверка ограниченной модели ст. 5 № 256-ФЗ, ред. 20.02.2026.
Запуск: python test_rules.py. Python 3.10+, без зависимостей.
q — срок рассмотрения дополнительного запроса, None если запроса нет.
s — независимо установленное основание приостановления; q не определяет s.
Все времена — уже вычисленные целые рабочие дни. Не проверяются календарь,
право на капитал, фактическое поступление сведений или содержание основания.
"""
from itertools import product
from pathlib import Path
import csv, json, sys
OUT=Path(__file__).resolve().parent
OK='допустимо'; BAD='нарушение'; INVALID='некорректный ввод'
# s,d,t,r,b,q: приостановление, решение, уведомление, отказ, основание, запрос.
def model(x, mutant=None):
    s,d,t,r,b,q=x
    if d<0 or t<0 or (q is not None and q<0): return INVALID
    lim=15 if s else 5
    if mutant=='always5': lim=5
    if mutant=='always15': lim=15
    if mutant=='limit20' and s: lim=20
    tests=[d<=lim, mutant=='no_notice' or t<=1,
           mutant=='no_reason' or not r or bool(b),
           mutant=='no_request' or q is None or q<=(2 if mutant=='request2' else 1)]
    return OK if all(tests) else BAD
# Ожидания для отдельных сценариев заданы вручную по ограничениям, до расчёта.
CASES=[
('T01',(0,5,1,0,0,None),OK,'общий срок: граница'),
('T02',(0,6,1,0,0,None),BAD,'общий срок: превышение'),
('T03',(1,6,1,0,0,None),OK,'приостановление: более 5 дней'),
('T04',(1,15,1,0,0,None),OK,'предельный срок: граница'),
('T05',(1,16,1,0,0,None),BAD,'предельный срок: превышение'),
('T06',(0,5,2,0,0,None),BAD,'просрочено уведомление'),
('T07',(0,5,1,1,0,None),BAD,'отказ без основания'),
('T08',(0,5,1,1,1,None),OK,'отказ с основанием'),
('T09',(0,5,1,0,0,0),OK,'запрос: рассмотрение в тот же день'),
('T10',(0,5,1,0,0,1),OK,'запрос: предельный срок'),
('T11',(0,5,1,0,0,2),BAD,'запрос: превышение срока'),
('T12',(1,15,1,0,0,2),BAD,'приостановление не снимает контроль запроса'),
('T13',(0,0,0,0,0,None),OK,'нулевые интервалы'),
('T14',(0,-1,1,0,0,None),INVALID,'отрицательный интервал решения'),
('T15',(0,5,-1,0,0,None),INVALID,'отрицательный интервал уведомления'),
('T16',(0,5,1,0,0,-1),INVALID,'отрицательный интервал запроса'),
]
MUTANTS={'always5':'срок решения всегда 5','always15':'срок решения всегда 15','limit20':'предел при приостановлении 20','no_notice':'удалён контроль уведомления','no_reason':'удалён контроль основания отказа','no_request':'удалён контроль срока запроса','request2':'срок запроса увеличен до 2'}
def oracle(x):
    # Альтернативная табличная реализация тех же допущений, не независимая юридическая экспертиза.
    s,d,t,r,b,q=x
    if any(v is not None and v<0 for v in (d,t,q)): return INVALID
    allowed_days={0:set(range(6)),1:set(range(16))}
    allowed_outcomes={(0,0),(0,1),(1,1)}
    return OK if d in allowed_days[s] and t in {0,1} and (r,b) in allowed_outcomes and q in {None,0,1} else BAD

def write_csv(name,header,rows):
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f,delimiter=';');w.writerow(header);w.writerows(rows)

def main():
    results=[(i,*x,exp,model(x),exp==model(x),note) for i,x,exp,note in CASES]
    write_csv('scenarios.csv',['id','s','d','t','r','b','q','ожидание','результат','совпадение','описание'],results)
    muts=[]
    for key,desc in MUTANTS.items():
        hits=[i for i,x,exp,_ in CASES if model(x,key)!=exp]
        muts.append((key,desc,len(hits),', '.join(hits),bool(hits)))
    write_csv('mutations.csv',['id','дефект','расхождений','сценарии','обнаружен'],muts)
    space=product(range(2),range(-1,17),range(-1,3),range(2),range(2),[None,-1,0,1,2])
    exhaustive=[(x,oracle(x),model(x)) for x in space]
    mismatches=[(x,a,b) for x,a,b in exhaustive if a!=b]
    summary={'python':sys.version.split()[0],'scenarios':len(results),'passed':sum(r[-2] for r in results),'mutants':len(muts),'detected':sum(r[-1] for r in muts),'enumerated':len(exhaustive),'mismatches':len(mismatches),'llm_runs':0}
    (OUT/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2));print(*muts,sep='\n')
    assert summary['passed']==len(results) and summary['detected']==len(muts) and not mismatches
if __name__=='__main__': main()
