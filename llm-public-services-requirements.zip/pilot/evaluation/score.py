import csv, pathlib, sys, statistics, collections

def read(p):
    with p.open(encoding='utf-8-sig',newline='') as f: return list(csv.DictReader(f,delimiter=';'))

def score(N,n,u,covered,ref):
    if not (0<=n<=N and 0<=u<=N-n and covered<=ref): raise ValueError('Некорректные количества или ID правил')
    return (n/N if N else None,len(covered)/len(ref),u/N if N else None)

def main():
    root=pathlib.Path(__file__).resolve().parent; folder=pathlib.Path(sys.argv[1]) if len(sys.argv)>1 else root/'results'; ref={r['id'] for r in read(root/'reference_rules.csv')}; runs={r['id']:r for r in read(folder/'runs.csv') if r['status']=='ok'}; rows=[]; groups=collections.defaultdict(list); seen=set()
    for r in read(folder/'ratings.csv'):
        if not all(r[k].strip() for k in ('N','n','u')): continue
        id=r['id']; assert id in runs and id not in seen; seen.add(id); s=runs[id]; covered=set(filter(None,(x.strip() for x in r['covered_ids'].split(',')))); vals=score(*(int(r[k]) for k in ('N','n','u')),covered,ref); rows.append([id,s['model'],s['mode'],*vals]); groups[(s['model'],s['mode'])].append(vals)
    if not rows: raise SystemExit('Нет размеченных ответов. Показатели не рассчитаны.')
    with (folder/'metrics.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f,delimiter=';');w.writerow(['id','model','mode','P','C','U']);w.writerows(rows)
    with (folder/'means.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f,delimiter=';');w.writerow(['model','mode','rated_runs','P_mean','C_mean','U_mean','P_valid','C_valid','U_valid']);
        for (model,mode),vs in sorted(groups.items()):
            cols=[[x for x in col if x is not None] for col in zip(*vs)];w.writerow([model,mode,len(vs),*[statistics.mean(c) if c else '' for c in cols],*[len(c) for c in cols]])
    print(f'Размечено {len(rows)} из {len(runs)} успешных запусков. Метрики записаны.')
if __name__=='__main__': main()
