import argparse, csv, datetime, hashlib, itertools, json, random, urllib.request, pathlib, time
ROOT=pathlib.Path(__file__).resolve().parent
PROMPTS={
'A':'На основании приведённого текста Федерального закона № 256-ФЗ сформируй функциональные требования к информационной системе выдачи государственного сертификата на материнский (семейный) капитал в заявительном порядке. Для каждого требования составь критерий приёмки.',
'B':'Выступи в роли бизнес-аналитика государственных услуг. Используй исключительно предоставленные нормативные фрагменты. Выдели атомарные правила, указывая структурную единицу источника, субъект, условие, действие, срок, единицу измерения, событие начала отсчёта и исключения, если применимо. Сформируй функциональные требования и проверочные сценарии, включая граничные значения, где применимо. Отдельно обозначь проектные допущения и сведения, требующие уточнения. Не добавляй отсутствующие в источнике основания отказа, документы или сроки. Представь результат в структурированной таблице.'}

def api(base, path, payload=None):
    req=urllib.request.Request(base.rstrip('/')+path, data=None if payload is None else json.dumps(payload,ensure_ascii=False).encode(), headers={'Content-Type':'application/json'})
    with urllib.request.urlopen(req,timeout=1800) as r: return json.load(r)

def dump(path,obj): path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')

def main():
    p=argparse.ArgumentParser(); p.add_argument('--corpus',type=pathlib.Path,default=ROOT/'corpus.txt'); p.add_argument('--models',nargs='+',default=['deepseek-r1:1.5b','qwen2.5:1.5b']); p.add_argument('--base',default='http://localhost:11434'); p.add_argument('--out',type=pathlib.Path,default=ROOT/'results'); a=p.parse_args()
    if not a.corpus.is_file(): p.error('Создайте corpus.txt по инструкции README.md.')
    raw=a.corpus.read_bytes(); corpus=raw.decode('utf-8-sig').strip(); assert len(corpus)>500,'Слишком короткий корпус'
    a.out.mkdir(parents=True,exist_ok=False); (a.out/'corpus.txt').write_bytes(raw)
    h=hashlib.sha256(raw).hexdigest(); tags=api(a.base,'/api/tags'); version=api(a.base,'/api/version'); available={m['name']:m for m in tags['models']}; missing=set(a.models)-available.keys()
    if missing: raise SystemExit(f'Не установлены модели: {missing}')
    dump(a.out/'manifest.json',{'corpus_sha256':h,'models':{m:available[m] for m in a.models},'ollama':version,'prompts':PROMPTS,'scope':'Ст. 5 ч. 3, 4, 5, 7; заявительный порядок','repetitions':3,'temperature':0.2,'num_ctx':8192,'num_predict':4096})
    jobs=list(itertools.product(a.models,PROMPTS,range(1,4))); random.Random(256).shuffle(jobs)
    rows=[]
    for i,(model,mode,rep) in enumerate(jobs,1):
        id=f'R{i:02}'; prompt=PROMPTS[mode]+'\n\nНормативный текст:\n'+corpus
        payload={'model':model,'messages':[{'role':'user','content':prompt}],'stream':False,'options':{'temperature':0.2,'seed':2026+rep,'num_ctx':8192,'num_predict':4096}}
        record={'id':id,'model':model,'mode':mode,'repeat':rep,'corpus_sha256':h,'started_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'request':payload}; t=time.monotonic()
        try:
            response=api(a.base,'/api/chat',payload); record['response']=response; content=response['message']['content']; status='ok' if content.strip() and response.get('done_reason')!='length' else 'incomplete'; (a.out/f'{id}.txt').write_text(content,encoding='utf-8')
        except Exception as e: record['error']=repr(e); status='error'
        record['elapsed_seconds']=time.monotonic()-t; record['status']=status; dump(a.out/f'{id}.json',record); rows.append([id,model,mode,rep,status]); print(id,model,mode,status,flush=True)
        with (a.out/'runs.csv').open('w',encoding='utf-8-sig',newline='') as f:
            w=csv.writer(f,delimiter=';'); w.writerow(['id','model','mode','repeat','status']); w.writerows(rows)
    with (a.out/'ratings.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f,delimiter=';'); w.writerow(['id','N','n','u','covered_ids','notes']); w.writerows([[r[0],'','','','',''] for r in rows if r[-1]=='ok'])
if __name__=='__main__': main()
